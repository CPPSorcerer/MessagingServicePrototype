import { Box } from "@mui/material";
import { Stack } from "phosphor-react";
import React from "react";
import { Chat_History } from "../../data";
import { TextMsg, Timeline } from "./MsgTypes";

const Messages = () => {
    return (
        <Box p={3}>
            <Stack spacing={3}>
                {Chat_History.map((el) => {
                    switch (el.type) {
                        case "divider":
                            //Timeline
                            return <Timeline el={el} />

                        case "msg":
                            switch (el.subtype) {
                                case "img":
                                    //img msg
                                    break;
                                case "doc":
                                    //Doc msg
                                    break;
                                case "link":
                                    //Link msg
                                    break;
                                case "reply":
                                    //reply msg
                                    break;

                                default:
                                    //text msg
                                 return <TextMsg el ={el}/>
                            }

                            break;
                        default:
                            return <></>;
                    }
                })}

            </Stack>

        </Box>
    )
}

export default Messages