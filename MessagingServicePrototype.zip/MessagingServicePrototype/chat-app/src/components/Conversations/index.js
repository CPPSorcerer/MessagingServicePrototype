import React from "react";
import { Stack, Box } from "@mui/material";
import ChatHeader from "../Chat/Header";
import Footer from "../Chat/Footer";
import Messages from "./Messages"


const Conversation = () => {
    return (
        <Stack height={"100%"} maxHeight={"100vh"} width={"auto"}>
            {/*Chat Header*/}
            <ChatHeader/>
            {/*Msg*/}
            <Box width={"100%"} sx={{ flexGrow: 1, }}>
                <Messages/>
            </Box>
            {/*Chat Footer*/}
            <Footer/>
        </Stack>
    )
}

export default Conversation;